# Compulsory-exercise-until-session-9
Compulsory exercise until session 9
Members of the group: Miguel Torregrosa, Carlos Rodrigo, Adrián Vico 
